'use strict';

/**
 * Injected by <Crank /> (React) or the optional Vite plugin / bookmarklet.
 * Loads the Crank panel from the companion that served this script.
 */
(function () {
  if (
    window.__CRANK_LOADER__ &&
    (document.getElementById('vp-shell') || document.getElementById('vp-crank-reopen'))
  ) {
    return;
  }
  window.__CRANK_LOADER__ = true;

  var params = new URLSearchParams(window.location.search);
  var autoload =
    params.get('crank') === '1' ||
    params.get('crank_autoload') === '1' ||
    localStorage.getItem('crank:autoload') === '1' ||
    true; // always on in dev when this script is injected

  if (!autoload) {
    return;
  }

  var script = document.createElement('script');
  var base = script.src || '';
  // Prefer same companion host this loader was served from.
  var companion =
    (document.currentScript && document.currentScript.src) ||
    'http://127.0.0.1:3344/dev-loader.js';
  var origin;
  try {
    origin = new URL(companion).origin;
  } catch (e) {
    origin = 'http://127.0.0.1:3344';
  }
  window.__CRANK_COMPANION__ = origin;
  script.src = origin + '/bookmarklet.js?t=' + Date.now();
  script.async = true;
  script.onerror = function () {
    console.error('[Crank] Failed to load bookmarklet from', script.src);
  };
  document.documentElement.appendChild(script);
})();
